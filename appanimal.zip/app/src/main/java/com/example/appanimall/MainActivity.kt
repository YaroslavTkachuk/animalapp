package com.example.appanimall

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var animal = Animal()
        animal.eachAnimal()

        var dog = Dog()
        var bird = Bird()
        var fish = Fish()

        bird.func2()
        dog.func1()

        var fishn = fish.a
        print("$fishn")
    }
}