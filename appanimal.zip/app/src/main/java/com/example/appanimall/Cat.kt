package com.example.appanimall

class Cat {

}
